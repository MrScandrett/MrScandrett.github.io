const config = {
  type: Phaser.AUTO,
  width: 800,
  height: 600,
  backgroundColor: '#1b263b',
  physics: {
    default: 'arcade',
    arcade: {
      gravity: { y: 300 },
      debug: false
    }
  },
  scene: {
    preload: preload,
    create: create,
    update: update
  }
};

const game = new Phaser.Game(config);
let player;
let platforms;
let cursors;

function preload() {
  // Load assets from Phaser's official test/demo CDN for instant running
  this.load.image('sky', 'https://labs.phaser.io/assets/skies/space3.png');
  this.load.image('ground', 'https://labs.phaser.io/assets/sprites/platform.png');
  this.load.image('logo', 'https://labs.phaser.io/assets/sprites/phaser3-logo.png');
  this.load.image('red', 'https://labs.phaser.io/assets/particles/red.png');
}

function create() {
  // Background
  this.add.image(400, 300, 'sky');

  // Particle emitter
  const particles = this.add.particles(0, 0, 'red', {
    speed: 100,
    scale: { start: 1, end: 0 },
    blendMode: 'ADD'
  });

  // Static platforms group
  platforms = this.physics.add.staticGroup();

  // Floor
  const floor = platforms.create(400, 568, 'ground');
  floor.setScale(2).refreshBody();

  // Elevated platforms
  platforms.create(600, 400, 'ground');
  platforms.create(50, 250, 'ground');
  platforms.create(750, 220, 'ground');

  // Player (using Phaser logo for physics test)
  player = this.physics.add.sprite(100, 450, 'logo');
  player.setScale(0.5);
  player.setBounce(0.2);
  player.setCollideWorldBounds(true);

  // Attach particles to player
  particles.startFollow(player);

  // Add collisions
  this.physics.add.collider(player, platforms);

  // Keyboard inputs
  cursors = this.input.keyboard.createCursorKeys();
}

function update() {
  if (cursors.left.isDown) {
    player.setVelocityX(-160);
  } else if (cursors.right.isDown) {
    player.setVelocityX(160);
  } else {
    player.setVelocityX(0);
  }

  if (cursors.up.isDown && player.body.touching.down) {
    player.setVelocityY(-330);
  }
}
