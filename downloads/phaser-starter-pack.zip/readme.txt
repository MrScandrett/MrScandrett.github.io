Phaser 3 2D Game Starter Pack
=============================

This starter pack has everything you need to start building 2D games with Phaser 3!

Files included:
- index.html: Sets up the page and loads Phaser 3 from CDN.
- game.js: Contains the starter game config, loading code, physics setup, and movement.
- readme.txt: This file.

How to run and code:
1. Extract this ZIP file into a project folder.
2. Open the folder in VS Code.
3. Run a local web server (like the VS Code "Live Server" extension) to play.
4. Modify game.js to load your own sprites, add custom physics, and build levels!

Documentation:
- Visit https://phaser.io/ for tutorials, examples, API reference, and guides.
