KAPLAY (formerly Kaboom.js) 2D Game Starter Pack
================================================

This starter pack has everything you need to start building 2D games with the KAPLAY engine!

Files included:
- index.html: Sets up the page and loads the KAPLAY library from CDN.
- game.js: Contains the starter game code (player movement, jumping, platforms).
- readme.txt: This file.

How to run and code:
1. Extract this ZIP file into a project folder.
2. Open the folder in VS Code.
3. Run a local web server (like the VS Code "Live Server" extension) to play.
4. Modify game.js to add sprites, sound effects, enemies, and new mechanics!

Documentation:
- Visit https://kaplayjs.com/ for full engine documentation, examples, and reference guides.
