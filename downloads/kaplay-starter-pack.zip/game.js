// Initialize KAPLAY
kaplay({
  width: 800,
  height: 600,
  background: [ 20, 20, 30 ],
  canvas: document.querySelector("canvas"),
});

// Load default bean character sprite
loadBean(); 

// Define main scene
scene("main", () => {
  // Add background text instructions
  add([
    text("Use Arrow Keys to Move & Jump", { size: 24 }),
    pos(width() / 2, 80),
    anchor("center"),
  ]);

  // Create the player object
  const player = add([
    sprite("bean"), // Use the loaded "bean" sprite
    pos(width() / 2, height() / 2),
    area(), // Give it a collision area
    body(), // Make it respond to physics/gravity
    anchor("center"),
  ]);

  // Add a platform for the player to land on
  add([
    rect(width() - 100, 48),
    pos(50, height() - 80),
    outline(4),
    area(),
    body({ isStatic: true }),
    color(127, 200, 255),
  ]);

  // Control bindings
  const SPEED = 320;
  const JUMP_FORCE = 800;

  onKeyDown("left", () => {
    player.move(-SPEED, 0);
  });

  onKeyDown("right", () => {
    player.move(SPEED, 0);
  });

  onKeyPress("up", () => {
    if (player.isGrounded()) {
      player.jump(JUMP_FORCE);
    }
  });

  // Reset if player falls off the screen
  player.onUpdate(() => {
    if (player.pos.y > height() + 100) {
      player.pos = vec2(width() / 2, height() / 2);
      player.vel = vec2(0, 0);
    }
  });
});

// Start the game
go("main");
