Arduino Starter Sketches Pack
=============================

A collection of clean, annotated starter code files for electronics and robotics projects.

Folders included:
- BlinkWithoutDelay/: Standard blinking code without using blocking delay(), perfect for multitasking robot controllers.
- SensorReading/: Boilerplate code to read analog sensors (potentiometers, photoresistors) and map them for PWM/serial readout.
- MotorControl/: Basic servo motor sweep code using the Servo library.

How to use:
1. Unzip this package.
2. Open the .ino file you want in the Arduino IDE.
3. Connect your Arduino board via USB.
4. Compile and upload!
