/*
  Sensor Reading boilerplate
  Reads an analog input on pin 0, maps the result to 0-255, and prints
  both values to the Serial Monitor.
*/

const int sensorPin = A0; // pin that the sensor/potentiometer is attached to
int rawValue = 0;         // variable to store the value read from the sensor pin
int mappedValue = 0;      // variable to store the mapped PWM/brightness value

void setup() {
  // initialize serial communications at 9600 bps:
  Serial.begin(9600);
}

void loop() {
  // read the analog in value:
  rawValue = analogRead(sensorPin);
  // map it to the range of the analog out (0 - 255):
  mappedValue = map(rawValue, 0, 1023, 0, 255);

  // print the results to the Serial Monitor:
  Serial.print("Raw Sensor Value = ");
  Serial.print(rawValue);
  Serial.print("\t Mapped Value (0-255) = ");
  Serial.println(mappedValue);

  // wait 50 milliseconds before the next loop for the analog-to-digital
  // converter to settle after the last reading:
  delay(50);
}
