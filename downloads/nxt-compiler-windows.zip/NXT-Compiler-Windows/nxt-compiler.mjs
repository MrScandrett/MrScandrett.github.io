#!/usr/bin/env node

// scripts/nxt-compiler-bridge.mjs
import http from "node:http";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { mkdtemp, writeFile, readFile, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

// assets/js/nxt/program.mjs
var DEFAULT_SENSORS = { touch: 1, sound: 2, light: 3, ultrasonic: 4, touch2: 0 };
var sensorNames = { touch: "Touch", sound: "Sound % (dBA weighting)", light: "Reflected light %", ultrasonic: "Distance cm", touch2: "Second touch", encoderA: "Motor A degrees", encoderB: "Motor B degrees", encoderC: "Motor C degrees" };
var num = (value) => ({ kind: "number", value });
var sensor = (name) => ({ kind: "sensor", name });
var variable = (name) => ({ kind: "variable", name });
var binary = (op, left, right) => ({ kind: "binary", op, left, right });
var identifiers = /^[A-Za-z][A-Za-z0-9_]{0,19}$/;
var ops = ["+", "-", "*", "/", "%", "<", "<=", ">", ">=", "==", "!=", "and", "or"];
function checkExpression(e, depth = 0) {
  if (depth > 12 || !e || typeof e !== "object") throw Error("Expression too deeply nested or missing.");
  if (e.kind === "number") {
    if (!Number.isFinite(e.value) || Math.abs(e.value) > 1e6) throw Error("Number outside \xB11,000,000.");
    return { kind: e.kind, value: e.value };
  }
  if (e.kind === "sensor") {
    if (!Object.hasOwn(sensorNames, e.name)) throw Error("Unknown sensor.");
    return { kind: e.kind, name: e.name };
  }
  if (e.kind === "variable") {
    if (!identifiers.test(e.name)) throw Error("Variable names use 1\u201320 letters, numbers or underscores, starting with a letter.");
    return { kind: e.kind, name: e.name };
  }
  if (e.kind === "binary" && ops.includes(e.op)) return { kind: e.kind, op: e.op, left: checkExpression(e.left, depth + 1), right: checkExpression(e.right, depth + 1) };
  throw Error("Unknown expression.");
}
function checkProgram(p) {
  if (p?.version !== 2 || !Array.isArray(p.steps) || !p.steps.length) throw Error("Use a version 2 block program with at least one instruction.");
  if (p.sensors && Object.keys(p.sensors).some((k) => !Object.hasOwn(DEFAULT_SENSORS, k))) throw Error("Unknown sensor configuration key.");
  const sensors = { ...DEFAULT_SENSORS, ...p.sensors };
  const used = /* @__PURE__ */ new Set();
  for (const key of Object.keys(DEFAULT_SENSORS)) {
    const port = sensors[key];
    if (!Number.isInteger(port) || port < 0 || port > 4) throw Error("Sensor ports must be 0 (absent) or 1\u20134.");
    if (port && used.has(port)) throw Error("Give each physical sensor its own input port.");
    if (port) used.add(port);
  }
  let count = 0;
  function steps(list, depth = 0) {
    if (!Array.isArray(list) || depth > 8) throw Error("Blocks are nested too deeply.");
    return list.map((s) => {
      if (++count > 300) throw Error("Maximum 300 instruction blocks.");
      const n = { type: s.type };
      if (typeof s.id === "string") n.id = s.id.slice(0, 100);
      switch (s.type) {
        case "drive":
          n.left = checkExpression(s.left);
          n.right = checkExpression(s.right);
          n.degrees = checkExpression(s.degrees);
          break;
        case "motor":
          if (![0, 1, 2].includes(s.port)) throw Error("Choose motor A, B or C.");
          n.port = s.port;
          n.power = checkExpression(s.power);
          n.degrees = checkExpression(s.degrees);
          break;
        case "wait":
          n.ms = checkExpression(s.ms);
          break;
        case "tone":
          n.frequency = checkExpression(s.frequency);
          n.ms = checkExpression(s.ms);
          break;
        case "sound":
          if (!/^[A-Za-z0-9_-]{1,15}\.rso$/i.test(s.file)) throw Error("Sound filename must be 1\u201315 simple characters plus .rso.");
          n.file = s.file;
          n.ms = checkExpression(s.ms);
          break;
        case "set":
          if (!identifiers.test(s.name)) throw Error("Invalid variable name.");
          n.name = s.name;
          n.value = checkExpression(s.value);
          break;
        case "sample":
          n.label = String(s.label || "sample").slice(0, 40);
          n.value = checkExpression(s.value);
          break;
        case "repeat":
          n.count = checkExpression(s.count);
          n.body = steps(s.body, depth + 1);
          break;
        case "while":
          n.condition = checkExpression(s.condition);
          n.limit = checkExpression(s.limit);
          n.body = steps(s.body, depth + 1);
          break;
        case "if":
          n.condition = checkExpression(s.condition);
          n.then = steps(s.then, depth + 1);
          n.else = steps(s.else || [], depth + 1);
          break;
        case "resetEncoder":
          if (![0, 1, 2].includes(s.port)) throw Error("Invalid encoder.");
          n.port = s.port;
          break;
        case "stop":
        case "coast":
          break;
        default:
          throw Error("Unknown instruction: " + s.type);
      }
      return n;
    });
  }
  return { version: 2, sensors, steps: steps(p.steps) };
}

// assets/js/nxt/nxc.mjs
function toNxc(input) {
  const p = checkProgram(input);
  let index = 0;
  const vars = /* @__PURE__ */ new Set();
  function expr(e) {
    if (e.kind === "number") return String(e.value);
    if (e.kind === "variable") {
      vars.add(e.name);
      return "v_" + e.name;
    }
    if (e.kind === "sensor") {
      if (e.name.startsWith("encoder")) return `MotorRotationCount(OUT_${e.name.at(-1)})`;
      const port = p.sensors[e.name];
      if (!port) throw Error(e.name + " sensor is absent.");
      return e.name === "ultrasonic" ? `SensorUS(IN_${port})` : `Sensor(IN_${port})`;
    }
    const a = expr(e.left), b = expr(e.right);
    if (e.op === "/") return `labDiv(${a}, ${b})`;
    if (e.op === "%") return `labMod(${a}, ${b})`;
    return `(${a} ${{ "and": "&&", "or": "||", "==": "==", "!=": "!=" }[e.op] || e.op} ${b})`;
  }
  function block(list, depth = 1) {
    const pad = "  ".repeat(depth);
    return list.map((s) => {
      const n = index++;
      switch (s.type) {
        case "drive":
          return `${pad}labMove(OUT_B, ${expr(s.left)}, OUT_C, ${expr(s.right)}, ${expr(s.degrees)});`;
        case "motor":
          return `${pad}labMove(OUT_${"ABC"[s.port]}, ${expr(s.power)}, OUT_${"ABC"[s.port]}, 0, ${expr(s.degrees)});`;
        case "wait":
          return `${pad}Wait(labClamp(${expr(s.ms)}, 0, 10000));`;
        case "tone":
          return `${pad}PlayTone(labClamp(${expr(s.frequency)},200,14000),labClamp(${expr(s.ms)},1,5000));
${pad}Wait(labClamp(${expr(s.ms)},1,5000));`;
        case "sound":
          return `${pad}PlayFile(${JSON.stringify(s.file)});
${pad}Wait(labClamp(${expr(s.ms)},1,8000));`;
        case "set":
          vars.add(s.name);
          return `${pad}v_${s.name} = labValue(${expr(s.value)});`;
        case "sample":
          return `${pad}TextOut(0, LCD_LINE1, ${JSON.stringify(s.label.replace(/[^A-Za-z0-9 _-]/g, "").slice(0, 16))}, true);
${pad}NumOut(0, LCD_LINE3, ${expr(s.value)}); // Browser CSV becomes LCD output on the brick.`;
        case "stop":
          return `${pad}OffEx(OUT_ABC,RESET_NONE);`;
        case "coast":
          return `${pad}CoastEx(OUT_ABC,RESET_NONE);`;
        case "resetEncoder":
          return `${pad}ResetRotationCount(OUT_${"ABC"[s.port]});`;
        case "repeat":
          return `${pad}int count${n}=labClamp(${expr(s.count)},0,100);
${pad}for(int i${n}=0; i${n}<count${n}; i${n}++){
${block(s.body, depth + 1)}
${pad}  Wait(5);
${pad}}`;
        case "while":
          return `${pad}int limit${n}=labClamp(${expr(s.limit)},1,100);
${pad}int i${n}=0;
${pad}while(${expr(s.condition)}){
${pad}  if(i${n}++ >= limit${n}){ OffEx(OUT_ABC,RESET_NONE); StopAllTasks(); }
${block(s.body, depth + 1)}
${pad}  Wait(5);
${pad}}`;
        case "if":
          return `${pad}if(${expr(s.condition)}){
${block(s.then, depth + 1)}
${pad}}else{
${block(s.else, depth + 1)}
${pad}}`;
      }
    }).join("\n");
  }
  const body = block(p.steps);
  const setup = Object.entries(p.sensors).filter(([, port]) => port).map(([kind, port]) => `  ${kind === "ultrasonic" ? "SetSensorUltrasonic" : kind === "light" ? "SetSensorLight" : kind === "sound" ? "SetSensorSound" : "SetSensorTouch"}(IN_${port}${kind === "sound" ? ",false" : ""});`).join("\n");
  return `// NXT Robot Lab \u2014 stock firmware 1.28+; compile with NBC/NXC, then send the .rxe.
// Browser sensor samples display on the brick LCD in standalone mode; CSV stays browser-only.
// Keep an adult at the power button. Test each mechanism with wheels lifted.
${[...vars].map((v) => "float v_" + v + "=0;").join("\n")}

int labMin(int a,int b){ if(a<b)return a; return b; }
int labMax(int a,int b){ if(a>b)return a; return b; }
int labClamp(float v,int lo,int hi){ int r=v; if(v-r>=0.5)r++; if(v-r< -0.5)r--; return labMax(lo,labMin(hi,r)); }
float labValue(float v){ if(abs(v)>1000000){ OffEx(OUT_ABC,RESET_NONE); StopAllTasks(); } return v; }
float labDiv(float a,float b){ if(b==0){ OffEx(OUT_ABC,RESET_NONE); StopAllTasks(); } return labValue(a/b); }
float labMod(float a,float b){ if(b==0){ OffEx(OUT_ABC,RESET_NONE); StopAllTasks(); } int q=a/b; return labValue(a-q*b); }
void labMove(byte a,int pa,byte b,int pb,int amount){
  int degrees=labClamp(amount,1,720); pa=labClamp(pa,-60,60); pb=labClamp(pb,-60,60);
  int fastest=labMax(abs(pa),abs(pb)); fastest=labMax(1,fastest);
  int targetA=labMax(1,labClamp(degrees*1.0*abs(pa)/fastest,1,720)); int targetB=labMax(1,labClamp(degrees*1.0*abs(pb)/fastest,1,720));
  long startA=MotorRotationCount(a); long startB=MotorRotationCount(b); long begin=CurrentTick();
  OnFwdEx(a,pa,RESET_NONE); if(b!=a) OnFwdEx(b,pb,RESET_NONE);
  bool doneA=(pa==0); bool doneB=(pb==0 || a==b);
  while(!doneA || !doneB){
    if(!doneA && abs(MotorRotationCount(a)-startA)>=targetA){ OffEx(a,RESET_NONE); doneA=true; }
    if(!doneB && abs(MotorRotationCount(b)-startB)>=targetB){ OffEx(b,RESET_NONE); doneB=true; }
    if(CurrentTick()-begin>10000){ OffEx(OUT_ABC,RESET_NONE); StopAllTasks(); }
    Wait(5);
  }
  OffEx(a,RESET_NONE); if(b!=a) OffEx(b,RESET_NONE);
}
task labWatchdog(){ Wait(120000); OffEx(OUT_ABC,RESET_NONE); StopAllTasks(); }
task main(){
  start labWatchdog;
${setup}
  Wait(300);
${body}
  OffEx(OUT_ABC,RESET_NONE);
  stop labWatchdog;
}
`;
}

// assets/js/nxt/projects.mjs
var drive = (left, right, degrees) => ({ type: "drive", left: num(left), right: num(right), degrees: num(degrees) });
var tone = (hz, ms = 200) => ({ type: "tone", frequency: num(hz), ms: num(ms) });
var wait = (ms) => ({ type: "wait", ms: num(ms) });
var motor = (power, degrees) => ({ type: "motor", port: 0, power: num(power), degrees: num(degrees) });
var repeat = (count, body) => ({ type: "repeat", count: num(count), body });
var choose = (condition, yes, no = []) => ({ type: "if", condition, then: yes, else: no });
var sample = (label, value) => ({ type: "sample", label, value });
var projects = {
  avoid: { name: "Obstacle patrol", category: "Navigation", needs: "Ultrasonic on 4", description: "Check distance before every short move. Turn when closer than 25 cm. Robot control remains in the browser until compiled.", steps: [repeat(20, [choose(binary("<", sensor("ultrasonic"), num(25)), [drive(-25, -25, 45), drive(25, -25, 100)], [drive(25, 25, 45)])])] },
  line: { name: "Follow the line", category: "Navigation", needs: "Light on 3; tape line", description: "Calibrate black and white readings, then replace 45 with their midpoint. Straddle the edge of a wide black line; short steps reduce overshoot.", steps: [repeat(30, [choose(binary("<", sensor("light"), num(45)), [drive(20, 35, 30)], [drive(35, 20, 30)])])] },
  forklift: { name: "Pick up & deliver", category: "Machines", needs: "Motor A lift; B/C drive", description: "Build a geared lifting attachment with end stops. Test a 90\xB0 lift without a load before moving a lightweight object.", steps: [drive(25, 25, 180), motor(25, 90), drive(-25, -25, 180), motor(-25, 90), tone(660)] },
  conveyor: { name: "Conveyor gate", category: "Machines", needs: "Touch on 1; motor A belt", description: "Use the touch switch as a start input, then advance a short conveyor segment. This is indexing, not color sorting.", steps: [{ type: "while", condition: binary("==", sensor("touch"), num(0)), limit: num(100), body: [wait(100)] }, motor(25, 360), tone(440)] },
  target: { name: "Touch target & score", category: "Games", needs: "Touch on 1", description: "Score three separate presses. Release between hits so a held button cannot earn multiple points. Uses a variable, math and bounded while loops.", steps: [{ type: "set", name: "score", value: num(0) }, repeat(3, [{ type: "while", condition: binary("==", sensor("touch"), num(0)), limit: num(100), body: [wait(100)] }, { type: "set", name: "score", value: binary("+", variable("score"), num(1)) }, sample("score", variable("score")), tone(880), { type: "while", condition: binary("==", sensor("touch"), num(1)), limit: num(100), body: [wait(100)] }])] },
  maze: { name: "Maze decision", category: "Games", needs: "Ultrasonic on 4; B/C drive", description: "A beginner reactive maze strategy: advance when clear, otherwise turn right. It can get trapped in loops; compare it with a wall-following algorithm.", steps: [repeat(25, [choose(binary(">", sensor("ultrasonic"), num(20)), [drive(25, 25, 60)], [drive(25, -25, 193)])])] },
  music: { name: "Clap-triggered music box", category: "Music", needs: "Sound on 2", description: "Wait for sound above 60% (a relative level, not calibrated decibels), then play a melody. Adjust the threshold for your classroom.", steps: [{ type: "while", condition: binary("<", sensor("sound"), num(60)), limit: num(100), body: [wait(100)] }, tone(262), tone(330), tone(392), tone(523, 500)] },
  instrument: { name: "Distance theremin", category: "Music", needs: "Ultrasonic on 4", description: "Map distance in centimeters to pitch using multiplication and addition. Move your hand in front of the sensor; 255 means no echo.", steps: [repeat(20, [{ type: "tone", frequency: binary("+", num(220), binary("*", sensor("ultrasonic"), num(5))), ms: num(100) }, wait(100)])] },
  measure: { name: "Wheel distance ruler", category: "Science", needs: "Motor B with 56 mm wheel", description: "Reset the encoder, turn the wheel, then calculate distance = rotation / 360 \xD7 \u03C0 \xD7 diameter. Change 56 to your measured wheel diameter; check slip and uncertainty.", steps: [{ type: "resetEncoder", port: 1 }, { type: "motor", port: 1, power: num(25), degrees: num(360) }, sample("distance_mm", binary("*", binary("/", sensor("encoderB"), num(360)), num(Math.PI * 56)))] },
  weather: { name: "Light & sound notebook", category: "Science", needs: "Light on 3; sound on 2", description: "Collect ten paired measurements for a CSV graph. The NXT sound sensor measures loudness, not voice content. Keep light distance and orientation constant.", steps: [repeat(10, [sample("light_percent", sensor("light")), sample("sound_percent", sensor("sound")), wait(500)])] },
  wind: { name: "Anemometer experiment", category: "Science", needs: "Cup rotor attached to motor A", description: "With motor A unpowered, turn a cup rotor by hand or with a fan. Record encoder angle each second. Compute RPM = change in degrees / 360 \xD7 60 / seconds; wind speed needs separate calibration.", steps: [{ type: "coast" }, { type: "resetEncoder", port: 0 }, repeat(10, [wait(1e3), sample("rotor_degrees", sensor("encoderA"))])] },
  remote: { name: "Two-button wired remote", category: "Remote control", needs: "Two touch sensors on 1/2; sound disconnected", description: "Requires an extra touch sensor. Left switch drives motor B; right switch drives C. Both go forward; neither means stop. This is a wired sensor remote, not a phone connection.", sensors: { ...DEFAULT_SENSORS, sound: 0, touch2: 2 }, steps: [repeat(60, [choose(sensor("touch"), [choose(sensor("touch2"), [drive(25, 25, 30)], [drive(25, 0, 30)])], [choose(sensor("touch2"), [drive(0, 25, 30)], [{ type: "stop" }, wait(100)])])])] }
};
function starterProgram(key, sensors = DEFAULT_SENSORS) {
  const p = projects[key];
  return { version: 2, sensors: structuredClone(p.sensors || sensors), steps: structuredClone(p.steps) };
}

// scripts/nxt-compiler-bridge.mjs
var exec = promisify(execFile);
var compilerMessage = (e) => e.code === "ENOENT" ? "NBC/NXC compiler not found. Use the Windows companion download, or set NXT_NBC to the full path of nbc.exe." : String(e.stderr || e.stdout || e.message).slice(0, 4e3);
function compilerRunner(compiler) {
  return (source, output) => exec(compiler, [source, "-O=" + output, "-v=128"], { cwd: path.dirname(source), timeout: 15e3, maxBuffer: 128e3, windowsHide: true });
}
async function compileProgram(program, compile) {
  const source = toNxc(program), dir = await mkdtemp(path.join(os.tmpdir(), "nxt-lab-"));
  try {
    const input = path.join(dir, "myrobot.nxc"), output = path.join(dir, "myrobot.rxe");
    await writeFile(input, source);
    await compile(input, output);
    const bytes = await readFile(output);
    if (bytes.length > 128e3 || bytes.subarray(0, 13).toString() !== "MindstormsNXT") throw Error("Compiler did not produce a valid NXT .rxe file.");
    return bytes;
  } catch (e) {
    if (e.path?.endsWith("myrobot.rxe") && e.code === "ENOENT") throw Error("The compiler exited without creating myrobot.rxe. Check its compatibility and diagnostics.");
    const error = Object.assign(Error(compilerMessage(e).replaceAll(dir, "[temporary project]")), { code: e.code });
    throw error;
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}
async function testCompiler(compile, { all = false } = {}) {
  const tone2 = { version: 2, sensors: { touch: 0, sound: 0, light: 0, ultrasonic: 0, touch2: 0 }, steps: [{ type: "tone", frequency: { kind: "number", value: 440 }, ms: { kind: "number", value: 100 } }] };
  await compileProgram(tone2, compile);
  if (all) for (const key of Object.keys(projects)) {
    try {
      await compileProgram(starterProgram(key), compile);
      console.log("Compiled starter: " + key);
    } catch (e) {
      throw Error(key + ": " + e.message);
    }
  }
}
function createCompilerServer({ compiler = process.env.NXT_NBC || "nbc", origins = ["http://127.0.0.1:8080", "http://localhost:8080", "https://mrscandrett.github.io"], compile = compilerRunner(compiler) } = {}) {
  let busy = false, health = null, healthPromise = null, checkedAt = 0;
  async function checkHealth() {
    if (health && Date.now() - checkedAt < (health.compilerReady ? 6e4 : 2e3)) return health;
    if (!healthPromise) healthPromise = (async () => {
      try {
        await testCompiler(compile);
        health = { compilerReady: true, message: "Compiler verified with a generated tone program." };
      } catch (e) {
        health = { compilerReady: false, message: compilerMessage(e) };
      }
      checkedAt = Date.now();
      return health;
    })().finally(() => {
      healthPromise = null;
    });
    return healthPromise;
  }
  return http.createServer(async (req, res) => {
    const host = String(req.headers.host || "");
    if (!/^(127\.0\.0\.1|localhost):\d+$/.test(host)) {
      res.writeHead(403);
      res.end("Loopback host required.");
      return;
    }
    const origin = req.headers.origin;
    if (origin && !origins.includes(origin)) {
      res.writeHead(403);
      res.end("Origin is not allowed.");
      return;
    }
    if (origin) res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.setHeader("Access-Control-Allow-Private-Network", "true");
    res.setHeader("Cache-Control", "no-store");
    if (req.method === "OPTIONS") {
      res.writeHead(204);
      res.end();
      return;
    }
    if (req.method === "GET" && req.url === "/health") {
      const result = busy ? health || { compilerReady: false, message: "Compiler is busy; check again after it finishes." } : await checkHealth();
      res.setHeader("Content-Type", "application/json");
      res.end(JSON.stringify({ service: "NXT local compiler", protocol: 1, ready: result.compilerReady, busy, ...result }));
      return;
    }
    if (req.method !== "POST" || req.url !== "/compile") {
      res.writeHead(404);
      res.end("Not found.");
      return;
    }
    if (busy || healthPromise) {
      res.writeHead(409);
      res.end("Compiler is busy. Try again shortly.");
      return;
    }
    busy = true;
    try {
      let body = "", length = 0;
      for await (const chunk of req) {
        length += chunk.length;
        if (length > 15e4) throw Error("Program exceeds 150 KB.");
        body += chunk.toString("utf8");
      }
      const bytes = await compileProgram(JSON.parse(body), compile);
      health = { compilerReady: true, message: "Compiler verified." };
      checkedAt = Date.now();
      busy = false;
      res.writeHead(200, { "Content-Type": "application/octet-stream", "Content-Disposition": 'attachment; filename="myrobot.rxe"' });
      res.end(bytes);
    } catch (e) {
      busy = false;
      if (!res.destroyed) {
        res.writeHead(e.code === "ENOENT" ? 503 : 400, { "Content-Type": "text/plain" });
        res.end(compilerMessage(e));
      }
    } finally {
      busy = false;
    }
  });
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const compiler = process.env.NXT_NBC || "nbc";
  if (process.argv.includes("--self-test")) {
    try {
      await testCompiler(compilerRunner(compiler), { all: true });
      console.log("NXT compiler verified: tone and all 12 starter projects compile. No robot was connected or moved.");
    } catch (e) {
      console.error(compilerMessage(e));
      process.exitCode = 1;
    }
  } else {
    const port = Number(process.env.NXT_COMPILER_PORT || 8791);
    const origins = ["http://127.0.0.1:8080", "http://localhost:8080", "https://mrscandrett.github.io", ...(process.env.NXT_COMPILER_ORIGINS || "").split(",").filter(Boolean)];
    const server = createCompilerServer({ compiler, origins });
    server.on("error", (e) => {
      console.error(e.code === "EADDRINUSE" ? "Port 8791 is already in use. An existing companion may already be running." : e.message);
      process.exitCode = 1;
    });
    server.listen(port, "127.0.0.1", () => console.log(`NXT compiler companion: http://127.0.0.1:${port}. Leave this window open, then use Check compiler in the website. No robot connection or firmware changes are performed.`));
  }
}
export {
  compileProgram,
  compilerRunner,
  createCompilerServer,
  testCompiler
};
