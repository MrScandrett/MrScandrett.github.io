param(
    [Parameter(Mandatory = $true)]
    [string]$Snapshot
)

$ErrorActionPreference = "Stop"

$root = Resolve-Path (Join-Path $PSScriptRoot "..")
$repoDir = Join-Path $root "update-repo"
$snapshotsDir = Join-Path $repoDir "snapshots"
$zipPath = Join-Path $snapshotsDir "$Snapshot.zip"

if (!(Test-Path $zipPath)) {
    throw "Snapshot not found: $zipPath"
}

$extractDir = Join-Path $env:TEMP "thomas_restore_$Snapshot"
if (Test-Path $extractDir) {
    Remove-Item -Recurse -Force $extractDir
}
New-Item -ItemType Directory -Path $extractDir | Out-Null

Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force

$items = Get-ChildItem -Path $extractDir -Force
foreach ($item in $items) {
    Copy-Item -Path $item.FullName -Destination $root -Recurse -Force
}

Remove-Item -Recurse -Force $extractDir
Write-Host "Rollback completed from snapshot: $Snapshot"
