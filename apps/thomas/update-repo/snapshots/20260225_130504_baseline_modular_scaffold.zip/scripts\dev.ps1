Write-Host "Open index.html in your browser to run the game."
