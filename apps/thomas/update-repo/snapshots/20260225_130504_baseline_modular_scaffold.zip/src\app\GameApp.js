import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';
import { COMBAT, PLAYER } from './config.js';
import { createTerrainSystem } from '../features/world/terrainSystem.js';
import { createTowerSystem } from '../features/structures/towerSystem.js';
import { createHealthDisplay } from '../ui/hud.js';
import { createMinimap } from '../ui/minimap.js';
import { createFpsMeter } from '../diagnostics/fpsMeter.js';

export function startGame() {
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x050510);
    scene.fog = new THREE.Fog(0x050510, 10, 100);

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    document.body.appendChild(renderer.domElement);

    camera.position.set(0, PLAYER.STAND_HEIGHT, 20);
    scene.add(camera);

    const light = new THREE.DirectionalLight(0xffffff, 1);
    light.position.set(10, 20, 10);
    light.castShadow = true;
    scene.add(light);
    scene.add(new THREE.AmbientLight(0x404040));

    const terrain = createTerrainSystem(scene);
    const { WORLD_RADIUS, getTerrainHeight, randomPointInWorld, isInsideWorld } = terrain;
    const towerSystem = createTowerSystem(scene, getTerrainHeight, randomPointInWorld, WORLD_RADIUS);

    const controls = new PointerLockControls(camera, document.body);

    const crosshair = document.createElement('div');
    crosshair.style.position = 'absolute';
    crosshair.style.top = '50%';
    crosshair.style.left = '50%';
    crosshair.style.width = '10px';
    crosshair.style.height = '10px';
    crosshair.style.backgroundColor = 'transparent';
    crosshair.style.border = '2px solid #00ff00';
    crosshair.style.borderRadius = '50%';
    crosshair.style.transform = 'translate(-50%, -50%)';
    crosshair.style.pointerEvents = 'none';
    document.body.appendChild(crosshair);

    const instructions = document.getElementById('instructions');
    instructions.style.position = 'absolute';
    instructions.style.top = '50%';
    instructions.style.left = '50%';
    instructions.style.transform = 'translate(-50%, -50%)';
    instructions.style.textAlign = 'center';
    instructions.style.color = 'white';
    instructions.style.backgroundColor = 'rgba(0,0,0,0.5)';
    instructions.style.padding = '20px';
    instructions.style.cursor = 'pointer';

    let useMic = false;
    const micBtn = document.createElement('button');
    micBtn.innerText = 'Microphone: OFF';
    micBtn.style.display = 'block';
    micBtn.style.margin = '20px auto 0 auto';
    micBtn.style.padding = '10px 20px';
    micBtn.style.fontSize = '16px';
    micBtn.style.cursor = 'pointer';
    micBtn.onclick = async (e) => {
        e.stopPropagation();
        if (!useMic) {
            try {
                await navigator.mediaDevices.getUserMedia({ audio: true });
                useMic = true;
                micBtn.innerText = 'Microphone: ON';
                micBtn.style.backgroundColor = '#44ff44';
            } catch (err) {
                alert('Microphone access denied. Please allow permission.');
            }
        } else {
            useMic = false;
            micBtn.innerText = 'Microphone: OFF';
            micBtn.style.backgroundColor = '';
        }
    };
    instructions.appendChild(micBtn);

    const libraryContainer = document.createElement('div');
    libraryContainer.style.position = 'absolute';
    libraryContainer.style.bottom = '0';
    libraryContainer.style.left = '0';
    libraryContainer.style.width = '100%';
    libraryContainer.style.height = '220px';
    libraryContainer.style.overflowX = 'auto';
    libraryContainer.style.whiteSpace = 'nowrap';
    libraryContainer.style.background = 'rgba(0,0,0,0.8)';
    libraryContainer.style.display = 'none';
    libraryContainer.style.padding = '10px';
    libraryContainer.style.zIndex = '1000';
    document.body.appendChild(libraryContainer);

    const libTitle = document.createElement('h3');
    libTitle.innerText = 'Gameplay Recordings';
    libTitle.style.color = 'white';
    libTitle.style.margin = '0 0 10px 0';
    libraryContainer.appendChild(libTitle);

    let mediaRecorder;
    let recordedChunks = [];
    async function startRecording() {
        recordedChunks = [];
        let finalStream;
        try {
            const canvasStream = renderer.domElement.captureStream(30);
            finalStream = canvasStream;

            if (useMic) {
                const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
                finalStream = new MediaStream([
                    ...canvasStream.getVideoTracks(),
                    ...audioStream.getAudioTracks()
                ]);
            }

            mediaRecorder = new MediaRecorder(finalStream, { mimeType: 'video/webm' });
            mediaRecorder.ondataavailable = (e) => {
                if (e.data.size > 0) recordedChunks.push(e.data);
            };
            mediaRecorder.onstop = () => {
                const blob = new Blob(recordedChunks, { type: 'video/webm' });
                const url = URL.createObjectURL(blob);

                const itemContainer = document.createElement('div');
                itemContainer.style.display = 'inline-block';
                itemContainer.style.marginRight = '10px';
                itemContainer.style.verticalAlign = 'top';
                itemContainer.style.textAlign = 'center';

                const video = document.createElement('video');
                video.src = url;
                video.controls = true;
                video.loop = true;
                video.playbackRate = 1.0;
                video.style.height = '150px';
                video.style.display = 'block';

                const saveBtn = document.createElement('button');
                saveBtn.innerText = 'Save Video';
                saveBtn.style.marginTop = '5px';
                saveBtn.style.cursor = 'pointer';
                saveBtn.onclick = () => {
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'letsplay_' + Date.now() + '.webm';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                };

                const deleteBtn = document.createElement('button');
                deleteBtn.innerText = 'Delete';
                deleteBtn.style.marginTop = '5px';
                deleteBtn.style.marginLeft = '5px';
                deleteBtn.style.cursor = 'pointer';
                deleteBtn.style.backgroundColor = '#ff4444';
                deleteBtn.style.color = 'white';
                deleteBtn.style.border = 'none';
                deleteBtn.onclick = () => {
                    itemContainer.remove();
                    URL.revokeObjectURL(url);
                };

                itemContainer.appendChild(video);
                itemContainer.appendChild(saveBtn);
                itemContainer.appendChild(deleteBtn);
                libraryContainer.appendChild(itemContainer);
                finalStream.getTracks().forEach(track => track.stop());
            };
            mediaRecorder.start();
        } catch (e) {
            console.warn('MediaRecorder setup failed', e);
        }
    }

    instructions.addEventListener('click', () => controls.lock());
    controls.addEventListener('lock', () => {
        instructions.style.display = 'none';
        libraryContainer.style.display = 'none';
        startRecording();
    });

    controls.addEventListener('unlock', () => {
        instructions.style.display = 'block';
        libraryContainer.style.display = 'block';
        isShielding = false;
        shieldMesh.visible = false;
        if (mediaRecorder && mediaRecorder.state === 'recording') {
            mediaRecorder.stop();
        }
    });

    const healthUi = createHealthDisplay();
    const minimap = createMinimap(WORLD_RADIUS);
    const fpsMeter = createFpsMeter();

    let playerHealth = 100;
    let playerLevel = 1;
    let score = 0;

    function updateHealthDisplay() {
        healthUi.update(playerHealth, playerLevel, score);
    }
    updateHealthDisplay();

    let moveForward = false;
    let moveBackward = false;
    let moveLeft = false;
    let moveRight = false;
    let canJump = false;
    let isSliding = false;
    let currentHeight = PLAYER.STAND_HEIGHT;
    let isFlipping = false;
    let flipStartTime = 0;
    const velocity = new THREE.Vector3();
    const direction = new THREE.Vector3();
    const snowballs = [];
    const particles = [];
    const bots = [];

    const onKeyDown = (e) => {
        if (e.code === 'KeyW') moveForward = true;
        if (e.code === 'KeyS') moveBackward = true;
        if (e.code === 'KeyA') moveLeft = true;
        if (e.code === 'KeyD') moveRight = true;
        if (e.code === 'Space' && canJump) {
            velocity.y += 150;
            canJump = false;
        }
        if (e.code === 'ShiftLeft') isSliding = true;
        if (e.code === 'KeyF' && !isFlipping) {
            isFlipping = true;
            flipStartTime = performance.now();
            velocity.y += 50;
            velocity.z += 100;
        }
    };
    const onKeyUp = (e) => {
        if (e.code === 'KeyW') moveForward = false;
        if (e.code === 'KeyS') moveBackward = false;
        if (e.code === 'KeyA') moveLeft = false;
        if (e.code === 'KeyD') moveRight = false;
        if (e.code === 'ShiftLeft') isSliding = false;
    };
    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('keyup', onKeyUp);

    const snowballGeometry = new THREE.SphereGeometry(0.5, 16, 16);
    const snowballMaterial = new THREE.MeshStandardMaterial({ color: 0x00ffff, emissive: 0x00aaaa, emissiveIntensity: 0.5 });
    const particleGeometry = new THREE.SphereGeometry(0.1, 4, 4);
    const particleMaterial = new THREE.MeshBasicMaterial({ color: 0xeeeeee });

    function createExplosion(position) {
        for (let i = 0; i < 20; i++) {
            const particle = new THREE.Mesh(particleGeometry, particleMaterial.clone());
            particle.material.transparent = true;
            particle.position.copy(position);
            particle.velocity = new THREE.Vector3(
                (Math.random() - 0.5) * 10,
                (Math.random() - 0.5) * 10,
                (Math.random() - 0.5) * 10
            );
            particle.life = 1.0;
            const scale = Math.random() * 0.5 + 0.5;
            particle.scale.set(scale, scale, scale);
            particles.push(particle);
            scene.add(particle);
        }
    }

    const shieldGeometry = new THREE.SphereGeometry(1.5, 32, 32);
    const shieldMaterial = new THREE.MeshBasicMaterial({ color: 0x00aaff, transparent: true, opacity: 0.2, side: THREE.DoubleSide });
    const shieldMesh = new THREE.Mesh(shieldGeometry, shieldMaterial);
    shieldMesh.visible = false;
    scene.add(shieldMesh);
    let isShielding = false;

    function createSnowball() {
        const snowball = new THREE.Mesh(snowballGeometry, snowballMaterial);
        snowball.castShadow = true;
        snowball.position.copy(controls.getObject().position);
        const initialVelocity = new THREE.Vector3();
        controls.getObject().getWorldDirection(initialVelocity);
        initialVelocity.multiplyScalar(COMBAT.SNOWBALL_SPEED);
        snowball.velocity = initialVelocity;
        snowball.isEnemy = false;
        return snowball;
    }

    document.addEventListener('mousedown', (event) => {
        if (!controls.isLocked) return;
        if (event.button === 0) {
            const snowball = createSnowball();
            snowballs.push(snowball);
            scene.add(snowball);
        } else if (event.button === 2) {
            isShielding = true;
            shieldMesh.visible = true;
        }
    });

    document.addEventListener('mouseup', (event) => {
        if (event.button === 2) {
            isShielding = false;
            shieldMesh.visible = false;
        }
    });
    document.addEventListener('contextmenu', (event) => event.preventDefault());

    function shootBotSnowball(bot, targetPos) {
        const snowball = new THREE.Mesh(snowballGeometry, snowballMaterial);
        snowball.castShadow = true;
        snowball.position.copy(bot.position);
        const directionToPlayer = new THREE.Vector3().subVectors(targetPos, bot.position).normalize();
        snowball.velocity = directionToPlayer.multiplyScalar(COMBAT.BOT_SNOWBALL_SPEED);
        snowball.isEnemy = true;
        snowballs.push(snowball);
        scene.add(snowball);
    }

    const botGeometry = new THREE.CylinderGeometry(0.8, 0.8, 3, 16);
    const botMaterial = new THREE.MeshStandardMaterial({ color: 0xff0000 });
    function createBot(x, z) {
        const bot = new THREE.Mesh(botGeometry, botMaterial);
        bot.position.set(x, getTerrainHeight(x, z) + 1.5, z);
        bot.castShadow = true;
        bot.receiveShadow = true;
        bot.health = 100;
        bot.lastShot = performance.now();

        const barBg = new THREE.Mesh(new THREE.PlaneGeometry(2, 0.2), new THREE.MeshBasicMaterial({ color: 0x550000 }));
        barBg.position.y = 2.5;
        bot.add(barBg);

        const barFg = new THREE.Mesh(new THREE.PlaneGeometry(2, 0.2), new THREE.MeshBasicMaterial({ color: 0x00ff00 }));
        barFg.position.z = 0.01;
        barBg.add(barFg);
        bot.healthBar = barFg;

        scene.add(bot);
        bots.push(bot);
    }

    let lastBotSpawn = 0;
    let prevTime = performance.now();
    function animate() {
        requestAnimationFrame(animate);
        const time = performance.now();
        const delta = (time - prevTime) / 1000;

        if (controls.isLocked) {
            const friction = (isSliding && canJump) ? 2.0 : 10.0;
            velocity.x -= velocity.x * friction * delta;
            velocity.z -= velocity.z * friction * delta;
            direction.z = Number(moveForward) - Number(moveBackward);
            direction.x = Number(moveRight) - Number(moveLeft);
            direction.normalize();

            const player = controls.getObject();
            const playerPos = player.position;
            const onLadder = towerSystem.isOnLadder(playerPos);
            if (onLadder) {
                velocity.y = 0;
                if (moveForward) velocity.y = 25;
                if (moveBackward) velocity.y = -20;
                canJump = true;
            } else {
                velocity.y -= PLAYER.GRAVITY * delta;
            }

            if (moveForward || moveBackward) velocity.z -= direction.z * PLAYER.MOVE_FORCE * delta;
            if (moveLeft || moveRight) velocity.x -= direction.x * PLAYER.MOVE_FORCE * delta;

            controls.moveRight(-velocity.x * delta);
            controls.moveForward(-velocity.z * delta);
            player.position.y += velocity.y * delta;

            const targetHeight = isSliding ? PLAYER.SLIDE_HEIGHT : PLAYER.STAND_HEIGHT;
            currentHeight += (targetHeight - currentHeight) * 10.0 * delta;
            const targetFOV = isSliding ? PLAYER.SLIDE_FOV : PLAYER.BASE_FOV;
            if (Math.abs(camera.fov - targetFOV) > 0.1) {
                camera.fov += (targetFOV - camera.fov) * 10.0 * delta;
                camera.updateProjectionMatrix();
            }

            const groundHeight = getTerrainHeight(playerPos.x, playerPos.z);
            if (player.position.y < groundHeight + currentHeight) {
                velocity.y = 0;
                player.position.y = groundHeight + currentHeight;
                canJump = true;
            }

            if (isFlipping) {
                const progress = (time - flipStartTime) / 600;
                if (progress < 1) {
                    const ease = progress * progress * (3 - 2 * progress);
                    camera.rotation.x = Math.PI * 2 * ease;
                } else {
                    camera.rotation.x = 0;
                    isFlipping = false;
                }
            }

            const playerDist = Math.hypot(player.position.x, player.position.z);
            const maxPlayerRadius = WORLD_RADIUS - 1;
            if (playerDist > maxPlayerRadius) {
                const scale = maxPlayerRadius / playerDist;
                player.position.x *= scale;
                player.position.z *= scale;
                velocity.x = 0;
                velocity.z = 0;
            }

            if (towerSystem.resolvePlayerCollisions(player, velocity, currentHeight)) {
                canJump = true;
            }

            shieldMesh.position.copy(player.position);

            if (time - lastBotSpawn > 3000 && bots.length < 3) {
                const spawn = randomPointInWorld(WORLD_RADIUS - 30);
                createBot(spawn.x, spawn.z);
                lastBotSpawn = time;
            }

            for (let i = 0; i < bots.length; i++) {
                const bot = bots[i];
                bot.lookAt(playerPos.x, bot.position.y, playerPos.z);
                const dir = new THREE.Vector3(playerPos.x - bot.position.x, 0, playerPos.z - bot.position.z).normalize();
                bot.position.add(dir.multiplyScalar(3.5 * delta));

                const botDist = Math.hypot(bot.position.x, bot.position.z);
                const maxBotRadius = WORLD_RADIUS - 1.5;
                if (botDist > maxBotRadius) {
                    const scale = maxBotRadius / botDist;
                    bot.position.x *= scale;
                    bot.position.z *= scale;
                }
                bot.position.y = getTerrainHeight(bot.position.x, bot.position.z) + 1.5;

                if (time - bot.lastShot > 2000) {
                    shootBotSnowball(bot, playerPos);
                    bot.lastShot = time;
                }

                if (bot.position.distanceTo(playerPos) < 1.5 && !isShielding) {
                    const damageMultiplier = Math.max(0.1, 1 - (playerLevel * 5) / 100);
                    playerHealth = Math.max(0, playerHealth - (20 * delta) * damageMultiplier);
                    updateHealthDisplay();
                }
            }

            for (let i = 0; i < snowballs.length; i++) {
                const snowball = snowballs[i];
                snowball.position.add(snowball.velocity.clone().multiplyScalar(delta));

                if (towerSystem.snowballHitsStructure(snowball)) {
                    createExplosion(snowball.position);
                    scene.remove(snowball);
                    snowballs.splice(i, 1);
                    i--;
                    continue;
                }

                if (snowball.isEnemy) {
                    if (snowball.position.distanceTo(player.position) < 1.5) {
                        createExplosion(snowball.position);
                        if (!isShielding) {
                            const damageMultiplier = Math.max(0.1, 1 - (playerLevel * 5) / 100);
                            playerHealth = Math.max(0, playerHealth - (10 * damageMultiplier));
                            updateHealthDisplay();
                        }
                        scene.remove(snowball);
                        snowballs.splice(i, 1);
                        i--;
                        continue;
                    }
                } else {
                    let hitBot = false;
                    for (let j = 0; j < bots.length; j++) {
                        const bot = bots[j];
                        if (snowball.position.distanceTo(bot.position) < 1.5) {
                            createExplosion(snowball.position);
                            bot.health -= 25;
                            bot.healthBar.scale.x = Math.max(0, bot.health / 100);

                            if (bot.health <= 0) {
                                createExplosion(bot.position);
                                scene.remove(bot);
                                bots.splice(j, 1);
                                playerLevel += 1;
                                score += 100;
                                updateHealthDisplay();
                            }
                            hitBot = true;
                            break;
                        }
                    }
                    if (hitBot) {
                        scene.remove(snowball);
                        snowballs.splice(i, 1);
                        i--;
                        continue;
                    }
                }

                if (snowball.position.y <= getTerrainHeight(snowball.position.x, snowball.position.z) + 0.5 ||
                    !isInsideWorld(snowball.position.x, snowball.position.z)) {
                    createExplosion(snowball.position);
                    scene.remove(snowball);
                    snowballs.splice(i, 1);
                    i--;
                    continue;
                }

                if (snowball.position.distanceTo(player.position) > 100) {
                    scene.remove(snowball);
                    snowballs.splice(i, 1);
                    i--;
                }
            }

            for (let i = 0; i < particles.length; i++) {
                const p = particles[i];
                p.life -= delta;
                p.material.opacity = p.life;
                p.velocity.y -= 9.8 * delta;
                p.position.add(p.velocity.clone().multiplyScalar(delta));
                if (p.life <= 0 || p.position.y <= 0) {
                    scene.remove(p);
                    p.material.dispose();
                    particles.splice(i, 1);
                    i--;
                }
            }
        }

        minimap.render(towerSystem.towers, bots, controls.getObject().position);
        fpsMeter.update(delta);
        prevTime = time;
        renderer.render(scene, camera);
    }

    animate();

    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
}
